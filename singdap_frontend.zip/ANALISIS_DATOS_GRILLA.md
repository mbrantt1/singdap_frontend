# Análisis de Fuentes de Datos: Grilla, Filtros y KPIs (ACTUALIZADO)

## 1. Columnas de la Grilla (El contenido)
Las filas y columnas que ves en la tabla **NO** se construyen a partir de archivos caché locales ni de cruces de información en el frontend.
- **Fuente:** Vienen listas y "cocinadas" desde el servidor a través del endpoint principal `/activos/catalogos`.
- **Mecanismo:** La grilla es **transaccional**. Muestra datos vivos. Cuando se recarga, el servidor entrega un paquete JSON con los datos ya resueltos (Textos finales, no solo IDs).
- **Validación:** La grilla muestra estrictamente lo que el servidor le entrega en tiempo real.

## 2. Filtros y Buscador (Desplegables y Caja de Texto)
Los menús desplegables (Comboboxes) de la barra superior ("Subsecretaría", "Tipo", "EIPD") ahora funcionan de manera optimizada:
- **Fuente Híbrida Inteligente (Caché + API):**
  - Al abrir la vista, el sistema consulta primero un archivo local (`catalog_cache.json`).
  - **Si el dato existe y es reciente (<24h):** Se carga INSTANTÁNEAMENTE desde el disco. No hay espera ni llamada de red.
  - **Si el dato no existe o expiró:** Se conecta silenciosamente a la API (`/setup/subsecretarias`, etc.), descarga la lista, la guarda en el archivo local para la próxima vez, y actualiza el desplegable.
- **Ejecución Asíncrona:** Este proceso ocurre en hilos paralelos (background threads) para no congelar la pantalla.
- **Beneficio:** Si ya abriste un formulario de "Nuevo Activo" antes, la grilla se beneficiará de ese caché y los filtros aparecerán *de inmediato* sin red.

## 3. Tarjetas Superiores (Indicadores KPI)
Los números grandes de la parte superior (Total Activos, Con datos sensibles, etc.):
- **Fuente:** Se obtienen de una llamada API exclusiva: `/activos/indicadores`.
- **Sincronización:** Esta llamada se ejecuta **en paralelo** con la carga de la grilla. Cada vez que filtras o cambias de página, se actualizan estos números para asegurar que coincidan con la vista actual.

## Resumen Técnico Simplificado
| Componente | Fuente de Datos | ¿Usa Caché Local? |
| :--- | :--- | :--- |
| **Texto en Columnas** | Respuesta directa API `/activos/catalogos` | **No**. Datos vivos transaccionales. |
| **Opciones Filtros** | APIs independientes (`/setup/...`, `/catalogos/...`) | **SÍ**. Sistema híbrido Caché/API que comparte datos con los formularios. |
| **Números KPIs** | API dedicada `/activos/indicadores` | **No**. Se calculan en tiempo real. |

**Mejora Reciente:** Ahora tanto el Formulario de "Nuevo Activo" como los Filtros de la Grilla comparten el mismo "cerebro" de catálogos (`CatalogoService`). Esto reduce drásticamente las llamadas al servidor y acelera la navegación entre pantallas.
